# ggfootball 0.1.0

* Initial CRAN submission

# ggfootball 0.0.0.9000

* First commit
* Added function for plotting xG/shots map using understat data `xg_map()`
* Added function for plotting xG charts using understat data `xg_chart()`
* Added `NEWS.md` and changed license from Apache to GPL v3
